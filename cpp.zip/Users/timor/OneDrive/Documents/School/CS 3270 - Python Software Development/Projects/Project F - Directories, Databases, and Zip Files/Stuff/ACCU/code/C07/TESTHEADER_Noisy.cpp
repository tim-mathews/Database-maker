//: .\C07:TESTHEADER_Noisy.cpp
//: C07:Noisy.h
// From "Thinking in C++, Volume 2", by Bruce Eckel & Chuck Allison.
// (c) 1995-2004 MindView, Inc. All Rights Reserved.
// See source code use permissions stated in the file 'License.txt',
// distributed with the code package available at www.MindView.net.
// A class to track various object activities.
// A Singleton. Will automatically report the
// statistics as the program terminates:
// Private constructor
// Disallowed
// Disallowed
// NOISY_H ///:~
#include"Noisy.h"
int main() {}
